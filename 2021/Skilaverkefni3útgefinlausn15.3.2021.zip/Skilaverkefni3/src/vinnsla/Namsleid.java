package vinnsla;

/******************************************************************************
 *  Nafn    : Ebba Þóra Hvannberg
 *  T-póstur: ebba@hi.is
 *
 *  Lýsing  : Gagnatag fyrir Námsleið
 *
 *****************************************************************************/
public enum Namsleid {
    NFVS11, // prufugögn
    NFVS12,
    NFVS21,
    NFVS22,
    NHEI11,
    NHEI12,
    NHEI21,
    NHEI22
}
