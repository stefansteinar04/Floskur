/******************************************************************************
 *  Nafn    : Ebba Þóra Hvannberg
 *  T-póstur: ebba@hi.is
 *
 *  Lýsing  : Gagnatag fyrir Deild
 *
 *****************************************************************************/
package vinnsla;

public enum Deild {
    HEI1, HEI2, FVS1, FVS2
}   // Prufugögn

