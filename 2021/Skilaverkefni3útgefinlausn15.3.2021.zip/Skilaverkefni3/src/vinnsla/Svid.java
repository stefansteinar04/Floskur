/******************************************************************************
 *  Nafn    : Ebba Þóra Hvannberg
 *  T-póstur: ebba@hi.is
 *
 *  Lýsing  : Gagnatag fyrir Svið
 *
 *****************************************************************************/
package vinnsla;

public enum Svid {
    FVS, HEI // prufugögn
}
