package vinnsla;

public enum Namsleid {
    HBV, TÖL, REI
}
