package vinnsla;

public enum Deild {
    IVT, LUD, RT, RAUN, UB, JVD, FMÞ, VID, HAG, LAG,FEL, STJ
}
