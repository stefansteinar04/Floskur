package vinnsla;

public enum Svid {
    VON, FVS, HEI, MVS, HUG
}
