package hi.verkefni.vinnsla;

/******************************************************************************
 *  Nafn    : Ebba Þóra Hvannberg
 *  T-póstur: ebba@hi.is
 *
 *  Lýsing  : Tegund spils, Hjarta, spaði, tígull lauf
 *
 *
 *****************************************************************************/
public enum Tegund {
    HJARTA,
    SPADI,
    TIGULL,
    LAUF
}
